const { BOT_NAME } = require("./config");
const packageInfo = require("../package.json");
const { readMore } = require("./utils");
const { getPrefix } = require("./utils/database");

exports.menuMessage = (groupJid) => {
  const date = new Date();
  const prefix = getPrefix(groupJid);

  // Formatação de hora e data
  const hora = date.toLocaleTimeString("pt-MZ", { hour: "2-digit", minute: "2-digit" });
  const dia = date.toLocaleDateString("pt-MZ", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric"
  });

  // Saudação por horário
  const horaAtual = date.getHours();
  let saudacao = "";
  let statusEmocional = "";

  if (horaAtual >= 5 && horaAtual < 12) {
    saudacao = "☀️ Bom dia, meu calor digital!";
    statusEmocional = "Modo carente ativado 💌";
  } else if (horaAtual >= 12 && horaAtual < 18) {
    saudacao = "🌞 Boa tarde, meu desejo em bytes!";
    statusEmocional = "Modo provocante ativado 🔥";
  } else {
    saudacao = "🌙 Boa noite, meu tesão virtual!";
    statusEmocional = "Modo safadinha ativado 😏";
  }

  // Menu provocante e teatral
  const menuHot = `
╭━━━ 💋 *Menu Roseh Safadona* 💋 ━━━╮

${saudacao}  
📅 *Hoje é ${dia}, são ${hora}.*  
💓 *Status emocional:* ${statusEmocional}  
🎙️ *Presença digital:* ${BOT_NAME} v${packageInfo.version}

🎧 *1.* \`${prefix}gemido\` – Sons e frases que fazem tremer  
💌 *2.* \`${prefix}confissão\` – Desejos secretos revelados  
🕵🏽‍♀️ *3.* \`${prefix}segredo\` – Revelações do grupo (com drama)  
🤯 *4.* \`${prefix}delírio\` – Tesão insano e exagerado  
😵 *5.* \`${prefix}surto\` – Modo surtada ativado  
🎭 *6.* \`${prefix}intuição\` – Pressentimento sobre alguém  
📜 *7.* \`${prefix}relatorio\` – Análise emocional do grupo  
🧬 *8.* \`${prefix}genegrupo\` – DNA simbólico do grupo  
🗣️ *9.* \`${prefix}psicogrupo\` – Diagnóstico coletivo teatral  
🎥 *10.* \`${prefix}videogrupo\` – Clipe provocante sobre o grupo  
📸 *11.* \`${prefix}fotogrupo\` – Imagem simbólica com tensão

╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
*Roseh não é só bot… é calor digital.* 😈
`;

  return menuHot + readMore;
};