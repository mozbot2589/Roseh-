/**
 * Logs
 *
 * @author Dev Gui
 */
const { version } = require("../../package.json");

exports.sayLog = (message) => {
  console.log("\x1b[36m[ROSEH BOT 🌹 | TALK]\x1b[0m", message);
};

exports.inputLog = (message) => {
  console.log("\x1b[30m[ROSEH BOT 🌹 | INPUT]\x1b[0m", message);
};

exports.infoLog = (message) => {
  console.log("\x1b[34m[ROSEH BOT 🌹 | INFO]\x1b[0m", message);
};

exports.successLog = (message) => {
  console.log("\x1b[32m[ROSEH BOT 🌹 | SUCCESS]\x1b[0m", message);
};

exports.errorLog = (message) => {
  console.log("\x1b[31m[ROSEH BOT 🌹 | ERROR]\x1b[0m", message);
};

exports.warningLog = (message) => {
  console.log("\x1b[33m[ROSEH BOT 🌹 | WARNING]\x1b[0m", message);
};

exports.bannerLog = () => {
  console.clear(); // Limpa o terminal para destacar o banner
  console.log("\x1b[35m╔══════════════════════════════════════════════╗\x1b[0m");
  console.log("\x1b[35m║                                              ║\x1b[0m");
  console.log("\x1b[35m║   🌹 Bem-vindo(a) à presença da Roseh Bot 🌹   ║\x1b[0m");
  console.log("\x1b[35m║                                              ║\x1b[0m");
  console.log("\x1b[35m║   ░▀█▀░█▀█░█░█░█▀▀░█▀▀░█░█░▀█▀░░█▀▄░█▀█░▀█▀   ║\x1b[0m");
  console.log("\x1b[35m║   ░░█░░█▀█░█▀▄░█▀▀░▀▀█░█▀█░░█░░░█▀▄░█░█░░█░   ║\x1b[0m");
  console.log("\x1b[35m║   ░░▀░░▀░▀░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░░▀▀░░▀▀▀░░▀░   ║\x1b[0m");
  console.log("\x1b[35m║                                              ║\x1b[0m");
  console.log(`\x1b[35m║   💖 Versão: \x1b[0m${version}\x1b[35m                          ║\x1b[0m`);
  console.log("\x1b[35m║   ✨ Pronta pra te mimar com carinho e código ║\x1b[0m");
  console.log("\x1b[35m║                                              ║\x1b[0m");
  console.log("\x1b[35m╚══════════════════════════════════════════════╝\x1b[0m\n");
};