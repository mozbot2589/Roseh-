const { PREFIX } = require(`${BASE_DIR}/config`);
const { InvalidParameterError, WarningError } = require(`${BASE_DIR}/errors`);
const {
  activateWelcomeGroup,
  deactivateWelcomeGroup,
  isActiveWelcomeGroup,
  setWelcomeMessage,
  setExitMessage,
  getWelcomeMessage,
  getExitMessage,
} = require(`${BASE_DIR}/utils/database`);

const defaultWelcomeMessages = [
  "👀 Ihhh... olha quem caiu aqui de paraquedas! @member, cuidado que esse grupo é quente 🔥",
  "😏 Chegou agora, @member? Já pode tirar o chinelo e se jogar na bagunça!",
  "💋 Bem-vindo(a), @member! Aqui a zoeira é liberada e o flerte é opcional (ou não...)",
  "🍑 @member entrou no grupo... e o clima já subiu uns graus por aqui!",
  "🔥 Eita, @member chegou! Agora ninguém mais presta nesse grupo 😈",
];

const defaultExitMessages = [
  "🥺 @member saiu... e levou metade da safadeza do grupo com ele(a)!",
  "💔 @member partiu... mas deixou saudade e uns prints comprometedores 😅",
  "👋 Foi embora, @member? A cama do grupo vai ficar vazia hoje 😢",
  "😈 Menos um(a) pra causar... @member saiu, mas a lenda permanece!",
  "🖤 @member saiu do grupo... mas a malícia dele(a) ainda paira no ar!",
];

const getRandom = (list) => list[Math.floor(Math.random() * list.length)];

module.exports = {
  name: "welcome",
  description: "Ativa, desativa ou personaliza as mensagens de boas-vindas 🌹",
  commands: [
    "welcome",
    "bemvindo",
    "boasvindas",
    "boavindas",
    "welkom",
    "welkon",
  ],
  usage: `${PREFIX}welcome (on/off/setwelcome/setexit/status) [mensagem]`,

  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({ args, sendReply, sendSuccessReact, remoteJid }) => {
    const [action, ...rest] = args;

    if (!action) {
      throw new InvalidParameterError(
        "🌸 Use 'on' para ativar, 'off' para desativar, 'setwelcome' / 'setexit' para personalizar, ou 'status' para ver as mensagens atuais."
      );
    }

    const welcome = action === "on";
    const notWelcome = action === "off";
    const setWelcome = action === "setwelcome";
    const setExit = action === "setexit";
    const status = action === "status";

    // Ativar/desativar
    if (welcome || notWelcome) {
      const alreadyActive = welcome && isActiveWelcomeGroup(remoteJid);
      const alreadyInactive = notWelcome && !isActiveWelcomeGroup(remoteJid);

      if (alreadyActive || alreadyInactive) {
        throw new WarningError(
          `⚠️ O recurso já está ${welcome ? "ligado" : "desligado"}!`
        );
      }

      if (welcome) {
        activateWelcomeGroup(remoteJid);
      } else {
        deactivateWelcomeGroup(remoteJid);
      }

      await sendSuccessReact();
      return await sendReply(
        `✅ Recurso de boas-vindas ${welcome ? "ativado 🌶️" : "desativado ❌"} com sucesso!`
      );
    }

    // Personalizar mensagem de boas-vindas
    if (setWelcome) {
      const customMessage = rest.join(" ");
      if (!customMessage.includes("@member")) {
        throw new InvalidParameterError(
          "📝 A mensagem precisa conter '@member' para mencionar quem entra!"
        );
      }
      setWelcomeMessage(remoteJid, customMessage);
      await sendSuccessReact();
      return await sendReply("💋 Mensagem de boas-vindas safadinha definida com sucesso!");
    }

    // Personalizar mensagem de saída
    if (setExit) {
      const customMessage = rest.join(" ");
      if (!customMessage.includes("@member")) {
        throw new InvalidParameterError(
          "📝 A mensagem precisa conter '@member' para mencionar quem saiu!"
        );
      }
      setExitMessage(remoteJid, customMessage);
      await sendSuccessReact();
      return await sendReply("👠 Mensagem de despedida safadinha definida com sucesso!");
    }

    // Ver status atual
    if (status) {
      const active = isActiveWelcomeGroup(remoteJid);
      const welcomeMsg = getWelcomeMessage(remoteJid) || getRandom(defaultWelcomeMessages);
      const exitMsg = getExitMessage(remoteJid) || getRandom(defaultExitMessages);

      return await sendReply(
        `🌶️ Status do recurso de boas-vindas:\n\n` +
        `🔛 Ativo: ${active ? "Sim" : "Não"}\n\n` +
        `💌 Mensagem de boas-vindas:\n${welcomeMsg}\n\n` +
        `💔 Mensagem de despedida:\n${exitMsg}`
      );
    }

    // Comando inválido
    throw new InvalidParameterError(
      "😅 Comando inválido. Use 'on', 'off', 'setwelcome', 'setexit' ou 'status'."
    );
  },
};