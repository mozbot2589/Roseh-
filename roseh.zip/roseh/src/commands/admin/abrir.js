const { PREFIX, BOT_EMOJI } = require(`${BASE_DIR}/config`);
const { errorLog } = require(`${BASE_DIR}/utils/logger`);

module.exports = {
  name: "abrir",
  description: "Roseh destranca o grupo e convoca o caos.",
  category: "Administração",
  commands: [
    "abrir",
    "abri",
    "abre",
    "abrir-grupo",
    "abri-grupo",
    "abre-grupo",
    "open",
    "open-group"
  ],
  usage: `${PREFIX}abrir`,
  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({ socket, remoteJid, sendSuccessReply, sendErrorReply }) => {
    try {
      await socket.groupSettingUpdate(remoteJid, "not_announcement");

      await sendSuccessReply(
        `${BOT_EMOJI} *Roseh destrancou os portões do grupo...*\n\n🌪️ As vozes foram libertas.\n🎭 Que cada alma encene sua verdade.\n\n*O palco está aberto. Que comece o espetáculo.*\n\n💡 _Dica de comando:_ use *${PREFIX}bot* para conhecer minha essência.`
      );
    } catch (error) {
      await sendErrorReply(
        `🚫 *Roseh foi impedida de abrir o grupo!*\n\n👑 Torne-me administradora para que eu possa liberar as vozes.\n\n*Por enquanto, o silêncio reina.*`
      );

      errorLog(
        `Falha lendária ao abrir o grupo:\n${JSON.stringify(error, null, 2)}`
      );
    }
  }
};