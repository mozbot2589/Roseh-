const { PREFIX } = require(`${BASE_DIR}/config`);
const { WarningError } = require(`${BASE_DIR}/errors`);

module.exports = {
  name: "get-id",
  description: "Mostra o ID do grupo, nome, dono e data de criação.",
  commands: ["get-id", "get-group-id", "id-get", "id-group"],
  usage: `${PREFIX}get-id`,
  category: "admin",
  permission: "admin",
  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({ remoteJid, sendSuccessReply, isGroup, groupMetadata }) => {
    if (!isGroup) {
      throw new WarningError("Este comando só funciona dentro de grupos, chefe!");
    }

    const groupName = groupMetadata?.subject || "Grupo sem nome";
    const ownerJid = groupMetadata?.owner || "Não identificado";
    const creationDate = groupMetadata?.creation
      ? new Date(groupMetadata.creation * 1000).toLocaleDateString("pt-BR")
      : "Desconhecida";

    const message = `🔍 *Investigando a zona...*\n` +
      `⌛ Roseh puxou os fios e achou tudo! 🌹\n\n` +
      `📍 *Informações da Zona*\n\n` +
      `🆔 *ID do grupo (JID)*: \`${remoteJid}\`\n` +
      `📛 *Nome do grupo*: ${groupName}\n` +
      `👑 *Criado por*: ${ownerJid}\n` +
      `📅 *Data de criação*: ${creationDate}\n\n` +
      `🌹 *Pronto, chefe!* Agora tens tudo na mão. Se quiseres o link do grupo, manda \`${PREFIX}link-grupo\` que eu te passo com carinho.\nTamos juntos na zona!`;

    await sendSuccessReply(message);
  },
};