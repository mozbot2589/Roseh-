const { PREFIX } = require(`${BASE_DIR}/config`);
const { activateGroup, activateGroupForDays } = require(`${BASE_DIR}/utils/database`);
const { WarningError } = require(`${BASE_DIR}/errors`);

module.exports = {
  name: "on",
  description: "Ativa o bot no grupo atual, por dias ou via ID.",
  commands: ["on"],
  usage: `${PREFIX}on [dias] | [id do grupo]`,
  category: "admin",
  permission: "admin",
  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({ args, remoteJid, isGroup, sendSuccessReply }) => {
    // Se o comando for usado sem argumentos dentro de um grupo
    if (args.length === 0 && isGroup) {
      activateGroup(remoteJid);
      return await sendSuccessReply(
        `✅ *Bot ativado com sucesso!*\n\n` +
        `🌹 A Roseh tá oficialmente presente nesse grupo.\n` +
        `Se quiser ver o menu, manda \`${PREFIX}menu\`. Tamos juntos na zona!`
      );
    }

    // Se o primeiro argumento for um número (dias)
    if (args.length === 1 && /^\d+$/.test(args[0]) && isGroup) {
      const dias = parseInt(args[0]);
      activateGroupForDays(remoteJid, dias);
      return await sendSuccessReply(
        `⏳ *Bot ativado por ${dias} dia(s)!*\n\n` +
        `🌹 A Roseh vai ficar firme aqui até lá. Se quiser estender depois, é só chamar!`
      );
    }

    // Se o primeiro argumento for um JID válido
    if (args.length === 1 && args[0].endsWith("@g.us")) {
      activateGroup(args[0]);
      return await sendSuccessReply(
        `📍 *Grupo ativado via ID!*\n\n` +
        `🆔 JID: \`${args[0]}\`\n` +
        `🌹 A Roseh tá pronta pra entrar em ação nesse grupo. Só chamar!`
      );
    }

    // Se os argumentos forem inválidos
    throw new WarningError(
      `❌ *Formato inválido!*\n\n` +
      `Use o comando assim:\n` +
      `• \`${PREFIX}on\` → ativa no grupo atual\n` +
      `• \`${PREFIX}on 3\` → ativa por 3 dias\n` +
      `• \`${PREFIX}on 12036302@g.us\` → ativa via ID de grupo`
    );
  },
};