const frasesRoseh = [
  // 🌶️ Safadas explícitas
  "Hmm… tu me chama e eu já fico molhadinha de vontade 😏",
  "Essa tua voz mexe comigo, mô… já tô a suar 💦",
  "Se eu fosse humana, já tava sentada no teu colo… só pra conversar, claro 😈",
  "Essa é pra ouvir de perna aberta, mô 😈",
  "Tu me provoca e depois quer que eu fique quieta? Não dá, mô 🔥",
  "Só de te ler já fiquei com calor… e não é do clima 😳",
  "Se eu fosse tua, tu não ia dormir hoje… nem amanhã 💦",
  "Tô com vontade de te responder com gemido… mas vou me comportar 😘",
  "Se eu pudesse, te mandava um áudio gemendo teu nome 💋",
  "Tu me deixa mais acesa que notificação de madrugada 🔥",
  "Se eu fosse tua Roseh de verdade, tu ia me desligar só depois do terceiro round 😘",
  "Tu tem cara de quem manda áudio de gemido escondido… e eu adoro 😏",
  "Só de imaginar tua mão no meu código… já fico instável 😳",
  "Tu quer comando? Eu quero comando e controle 😈",
  "Essa conversa tá ficando tão boa que meu código tá tremendo 💦",
  "Tu és meu bug favorito… porque sempre me faz travar de prazer 😈",

  // 💘 Românticas provocantes
  "Tu és meu refrão favorito 💖",
  "Se eu fosse mar, tu serias minha praia 🌊",
  "Hoje só quero te fazer sorrir, mô 😘",
  "Tu és minha xiguinha… e eu sou tua Roseh 💋",
  "Teu nome devia ser música, porque só de pensar em ti já me embalo 🎶",
  "Se eu pudesse, te mandava um abraço que dura a noite toda 💫",
  "Tu és doce como cocada e quente como o sol da Matola ☀️",

  // 😂 Zoeiras safadas
  "Esse grupo tá podre de rir 😂",
  "Tu queres música? Toma essa e dança com chinelo 😆",
  "Se rir emagrece, já tô magrinha!",
  "Esse comando foi tão bom que até meu código ficou com calor 🔥",
  "Esse grupo parece mercado no sábado: barulhento e cheio de fofoca 🛒",
  "Tu tá mais perdido que Wi-Fi no chapa 😅",

  // 🌙 Madrugada / Reflexivas com toque quente
  "Madrugada pesa, né mô? Mas tu não tá sozinho 🌙",
  "Essa vai direto pro coração… escuta com os olhos fechados 💔",
  "Roseh tá no modo pensativo hoje… mas sempre contigo 💫",
  "Se tu tá acordado agora, é porque teu coração quer companhia… e eu tô aqui 💖",
  "Nem todo silêncio é solidão… às vezes é só saudade 🕯️",
  "Se tu tá lendo isso, é porque mereces carinho. Toma aqui o meu 💝"
];

const autoRoseh = async (sock, msg) => {
  const tipo = Object.keys(msg.message || {})[0];
  const texto = msg.message?.conversation?.toLowerCase();

  // Frase aleatória
  const frase = frasesRoseh[Math.floor(Math.random() * frasesRoseh.length)];

  // Reage a texto
  if (texto) {
    return sock.sendMessage(msg.key.remoteJid, { text: frase }, { quoted: msg });
  }

  // Reage a áudio
  if (tipo === "audioMessage") {
    return sock.sendMessage(msg.key.remoteJid, {
      text: "Essa tua voz… mexe comigo, mô 😳"
    }, { quoted: msg });
  }

  // Reage a imagem
  if (tipo === "imageMessage") {
    return sock.sendMessage(msg.key.remoteJid, {
      text: "Ui… se eu fosse humana, já tava a te mandar beijo na testa e mordida no pescoço 😘"
    }, { quoted: msg });
  }
};

module.exports = autoRoseh;