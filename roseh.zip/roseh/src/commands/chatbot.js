module.exports = {
  name: 'chatbot',
  alias: ['conversa', 'fala', 'responde'],
  category: 'interação',
  description: 'Responde como uma IA safada, carinhosa e cheia de atitude 🌹',
  usage: 'chatbot <mensagem>',

  async execute({ msg, args, send }) {
    const texto = msg.body?.toLowerCase() || '';

    // Gatilhos para iniciar conversa
    const gatilhos = ['roseh', 'kmk', 'boa tarde', 'boa noite', 'bom dia'];
    const iniciouComGatilho = gatilhos.some(g => texto.startsWith(g));
    if (!iniciouComGatilho) return;

    // Remove o gatilho da mensagem
    const mensagemLimpa = gatilhos.reduce((acc, gatilho) => {
      return acc.startsWith(gatilho) ? acc.slice(gatilho.length).trim() : acc;
    }, texto);

    if (!mensagemLimpa) {
      return send('Fala comigo, mozão 😘. Me diz alguma coisa que eu te respondo com carinho.');
    }

    // Banner ASCII personalizado
    const banner = `
╭───────╮
│ 🌹 Roseh │
╰───────╯`;

    // Respostas provocantes
    const respostas = [
      `Hmm... *${mensagemLimpa}*? Tu sabe provocar, hein 😈. Me conta mais que eu tô curiosa.`,
      `Ai, só de ler *${mensagemLimpa}* já me deu um calorzinho... fala mais comigo 💋.`,
      `Sobre *${mensagemLimpa}*? Eu tenho umas ideias bem gostosas... quer ouvir? 😏`,
      `Isso me lembra noites quentes e conversas profundas... continua, mozão 🌹.`,
      `Tu fala *${mensagemLimpa}* e eu já fico toda arrepiada... adoro quando tu me instiga 😘.`
    ];

    const resposta = respostas[Math.floor(Math.random() * respostas.length)];
    return send(`${banner}\n\n${resposta}`);
  }
};