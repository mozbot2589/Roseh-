const ytdl = require('ytdl-core');
const ytSearch = require('yt-search');
const { tmpdir } = require('os');
const { join } = require('path');
const { writeFileSync, unlinkSync } = require('fs');

const playAudioSafado = async (sock, msg, args) => {
  const query = args.join(' ').trim();
  if (!query) return sock.sendMessage(msg.key.remoteJid, {
    text: '❌ Diz o nome da música, mô... não me deixa na vontade 😏'
  });

  const { videos } = await ytSearch(query);
  if (!videos.length) return sock.sendMessage(msg.key.remoteJid, {
    text: '😢 Não achei nada com esse nome... tua safadeza vai ter que esperar 😩'
  });

  const video = videos[0];
  const { title, author, duration, image, url, published, views } = video;

  const audioStream = ytdl(url, { filter: 'audioonly', quality: 'highestaudio' });
  const filePath = join(tmpdir(), `${Date.now()}.mp3`);
  const chunks = [];

  for await (const chunk of audioStream) chunks.push(chunk);
  writeFileSync(filePath, Buffer.concat(chunks));

  // Mensagem safada com detalhes
  await sock.sendMessage(msg.key.remoteJid, {
    image: { url: image },
    caption: `🔞 *${title}*\n\n🎤 *Artista:* ${author.name}\n⏱️ *Duração:* ${duration.timestamp}\n📅 *Publicado:* ${published}\n👁️ *Views:* ${views.toLocaleString()} 👀\n🔗 *Link:* ${url}\n\nEssa aqui é pra ouvir de perna aberta, mô 😏\nRoseh Bot tá te servindo gostoso hoje 💦`,
  }, { quoted: msg });

  // Mensagem provocante antes do áudio
  await sock.sendMessage(msg.key.remoteJid, {
    text: `🎧 Segura esse som, mô... pra te deixar molhadinhx de emoção 😈`,
  }, { quoted: msg });

  // Envia o áudio como PTT
  await sock.sendMessage(msg.key.remoteJid, {
    audio: { url: filePath },
    mimetype: 'audio/mp4',
    ptt: true
  }, { quoted: msg });

  unlinkSync(filePath);
};

module.exports = playAudioSafado;