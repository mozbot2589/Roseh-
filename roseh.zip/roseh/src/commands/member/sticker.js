/**
 * Desenvolvido por: Dev Júnio & Roseh Bot 🌺
 * Implementação dos metadados feita por: MRX
 *
 * @description Cria figurinhas provocantes a partir de imagem, gif ou vídeo (máx. 10s).
 * Com frases quentes, reações safadas e presença Mozambicana.
 */

const fs = require("node:fs");
const path = require("node:path");
const { exec } = require("node:child_process");

const { getRandomName } = require(`${BASE_DIR}/utils`);
const { addStickerMetadata } = require(`${BASE_DIR}/services/sticker`);
const { InvalidParameterError } = require(`${BASE_DIR}/errors`);
const { PREFIX, TEMP_DIR } = require(`${BASE_DIR}/config`);

module.exports = {
  name: "rosehsticker",
  description: "Cria figurinhas com safadeza e presença Mozambicana 🌺",
  commands: ["rosehsticker", "f", "s", "sticker", "fig"],
  usage: `${PREFIX}rosehsticker (responde imagem/gif/vídeo até 10s)`,

  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({
    isImage,
    isVideo,
    downloadImage,
    downloadVideo,
    webMessage,
    sendErrorReply,
    sendWaitReact,
    sendSuccessReact,
    sendStickerFromFile,
    sendText,
    react,
    userJid,
  }) => {
    if (!isImage && !isVideo) {
      throw new InvalidParameterError(
        `🌺 Amor, tu precisa responder uma imagem, gif ou vídeo de até 10 segundos pra virar figurinha 😘`
      );
    }

    await sendWaitReact("🌶️");

    const username =
      webMessage.pushName ||
      webMessage.notifyName ||
      userJid.replace(/@s.whatsapp.net/, "");

    const metadata = {
      username: username,
      botName: `🌺 Roseh Bot — feita pra provocar`,
    };

    const outputTempPath = path.resolve(TEMP_DIR, getRandomName("webp"));
    let inputPath = null;

    try {
      if (isImage) {
        for (let attempt = 1; attempt <= 3; attempt++) {
          try {
            inputPath = await downloadImage(webMessage, getRandomName());
            break;
          } catch (err) {
            if (attempt === 3) throw err;
            await new Promise((r) => setTimeout(r, 2000 * attempt));
          }
        }

        await new Promise((resolve, reject) => {
          const cmd = `ffmpeg -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease" -f webp -quality 90 "${outputTempPath}"`;
          exec(cmd, (error, _, stderr) => {
            if (error) reject(stderr);
            else resolve();
          });
        });
      } else {
        for (let attempt = 1; attempt <= 3; attempt++) {
          try {
            inputPath = await downloadVideo(webMessage, getRandomName());
            break;
          } catch (err) {
            if (attempt === 3) throw err;
            await new Promise((r) => setTimeout(r, 2000 * attempt));
          }
        }

        const maxDuration = 10;
        const seconds =
          webMessage.message?.videoMessage?.seconds ||
          webMessage.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage?.seconds;

        if (!seconds || seconds > maxDuration) {
          if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
          return sendErrorReply(`❌ O vídeo tem mais de ${maxDuration}s! Manda um menor, meu puto.`);
        }

        await new Promise((resolve, reject) => {
          const cmd = `ffmpeg -y -i "${inputPath}" -vcodec libwebp -fs 0.99M -filter_complex "[0:v] scale=512:512, fps=15, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse" -f webp "${outputTempPath}"`;
          exec(cmd, (error, _, stderr) => {
            if (error) reject(stderr);
            else resolve();
          });
        });
      }

      if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath);

      if (!fs.existsSync(outputTempPath)) {
        throw new Error("🌺 Figurinha não nasceu… FFmpeg falhou.");
      }

      const stickerPath = await addStickerMetadata(
        await fs.promises.readFile(outputTempPath),
        metadata
      );

      await sendSuccessReact("💋");

      const frases = [
        "🌺 Figurinha pronta, meu puto! Agora espalha esse drama no grupo 😏",
        "💋 Roseh te deu uma figurinha com beijo e provocação. Usa com moderação… ou não 😘",
        "🔥 Essa figurinha tá mais quente que conversa de madrugada!",
        "😈 Me cola no teu status e deixa o povo curioso…",
      ];

      await sendStickerFromFile(stickerPath);
      await sendText(frases[Math.floor(Math.random() * frases.length)]);

      if (fs.existsSync(outputTempPath)) fs.unlinkSync(outputTempPath);
      if (fs.existsSync(stickerPath)) fs.unlinkSync(stickerPath);
    } catch (error) {
      console.error("Erro no comando rosehsticker:", error);

      if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
      if (fs.existsSync(outputTempPath)) fs.unlinkSync(outputTempPath);

      throw new Error(
        `😢 Roseh não conseguiu criar tua figurinha.\nMotivo: ${error.message}`
      );
    }
  },
};