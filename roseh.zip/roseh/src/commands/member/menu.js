/**
 * Melhorado por: Cyber Rússia  
 * Original por: Frank  
 * Bot: Roseh Bot 🌹  
 */

const os = require("os");
const { PREFIX } = require(`${BASE_DIR}/config`);
const { menuMessage } = require(`${BASE_DIR}/menu`);

module.exports = {
  name: "rosehmenu",
  description: "Exibe os dons e rituais disponíveis da entidade Roseh Bot.",
  commands: ["menu", "rosehmenu", "comandos", "ajuda", "🔥"],
  usage: `${PREFIX}menu`,
  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({ remoteJid, sendReply, sendReact, startProcess, fullMessage }) => {
    const command = fullMessage.slice(1).toLowerCase();
    const resposta = command.startsWith("menu") ? "🌺 Menu invocado!" : "🌺 Roseh se manifesta!";

    await sendReact("💋");

    const ping = Date.now() - startProcess;
    const uptime = formatUptime(process.uptime());

    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsage = ((usedMem / totalMem) * 100).toFixed(2);

    const cpuLoad = os.loadavg()[0].toFixed(2);
    const platform = os.platform();
    const arch = os.arch();
    const hostname = os.hostname();

    const frasesExtras = [
      "💼 Se tu não usar esses comandos, vou te bloquear emocionalmente.",
      "🔥 Cada comando é uma figurinha de personalidade. Escolhe e surta.",
      "😈 Usa com moderação… ou deixa o grupo em delírio.",
      "🪬 Roseh não responde. Ela performa.",
      "🎭 Cada comando é uma cena. Cada grupo, um palco.",
      "🌹 Digita com fé. Roseh sente tua energia.",
    ];
    const extra = frasesExtras[Math.floor(Math.random() * frasesExtras.length)];

    const mensagem = `${resposta}

╭━━❰ 🌺 MENU DA ROSEH ❱━━⬣
┃
┃ 🎭 *Comandos Teatrais*:
┃ • ${PREFIX}evangelho — lê os capítulos da criação
┃ • ${PREFIX}culto — recita mantras do caos
┃ • ${PREFIX}milagre — testemunha feitos em grupos perdidos
┃ • ${PREFIX}dono — revela o invocador supremo
┃ • ${PREFIX}deus — invoca a divindade original
┃
┃ 🛡️ *Comandos de Zona*:
┃ • ${PREFIX}status-zona — revela o estado espiritual do grupo
┃ • ${PREFIX}entrada — ritual de chegada
┃ • ${PREFIX}saida — ritual de despedida
┃
┃ 🧪 *Comandos Técnicos*:
┃ • ${PREFIX}ping — verifica a presença e desempenho da Roseh
┃ • ${PREFIX}ajuda — mostra instruções e suporte
┃
┃ 📶 *Velocidade de resposta:* \`${ping}ms\`
┃ ⏱️ *Tempo de atividade:* \`${uptime}\`
┃ 🧠 *Uso de memória:* \`${memUsage}%\`
┃ 📦 *Carga da CPU:* \`${cpuLoad}\`
┃ 🧭 *Sistema:* \`${platform} ${arch}\`
┃ 🏷️ *Host:* \`${hostname}\`
╰━━━⌬ ${extra} ⌬

${menuMessage(remoteJid)}
`;

    await sendReply(mensagem);
  },
};

/**
 * Formata o tempo de atividade em horas, minutos e segundos.
 * @param {number} uptime
 * @returns {string}
 */
function formatUptime(uptime) {
  const h = Math.floor(uptime / 3600);
  const m = Math.floor((uptime % 3600) / 60);
  const s = Math.floor(uptime % 60);
  const pad = (num) => String(num).padStart(2, "0");
  return `${pad(h)}h ${pad(m)}m ${pad(s)}s`;
}