const { PREFIX } = require(`${BASE_DIR}/config`);
const { errorLog } = require(`${BASE_DIR}/utils/logger`);

module.exports = {
  name: "groupinfo",
  description: "Mostra informações básicas do grupo",
  commands: ["groupinfo", "grupo"],
  usage: `${PREFIX}groupinfo`,
  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({
    socket,
    remoteJid,
    sendSuccessReply,
    sendErrorReply,
  }) => {
    try {
      if (!remoteJid.endsWith("@g.us")) {
        return await sendErrorReply("Esse comando só funciona em grupos.");
      }

      // 🕒 Detecta modo por horário
      const modo = getModoPorHorario();
      const mensagemEspera = escolherMensagemEspera(modo);
      await sendSuccessReply(mensagemEspera);

      // 📊 Coleta dados do grupo
      const metadata = await socket.groupMetadata(remoteJid);
      const { subject, owner, participants } = metadata;

      const admins = participants.filter(p => p.admin);
      const adminList = admins
        .map((a, i) => `${i + 1}. @${a.id.split("@")[0]}`)
        .join("\n");

      const mensagemFinal = `
📌 *Nome do grupo:* ${subject}
👥 *Participantes:* ${participants.length}
👑 *Dono:* @${owner?.split("@")[0] || "desconhecido"}

🔐 *Administradores:*
${adminList || "_Nenhum admin encontrado_"}
      `.trim();

      await sendSuccessReply(mensagemFinal, {
        mentions: admins.map(a => a.id).concat(owner || []),
      });

    } catch (error) {
      errorLog(`Erro ao obter informações do grupo: ${error.message || error}`);
      await sendErrorReply("Não consegui buscar as informações do grupo.");
    }
  },
};

// 🕒 Detecta modo por horário
function getModoPorHorario() {
  const hora = new Date().getHours();
  if (hora >= 0 && hora < 5) return "madrugada";
  if (hora >= 5 && hora < 12) return "romantico";
  if (hora >= 12 && hora < 18) return "zoeira";
  return "neutro";
}

// 💬 Mensagens de espera por modo
const mensagensEspera = {
  madrugada: [
    "🌙 Puxando os dados na surdina da madrugada...",
    "😴 Madrugando? Calma que já te mostro tudo...",
    "🌌 Só os fortes tão acordados... preparando a resposta!",
  ],
  romantico: [
    "💖 Espera só um pouquinho, amor... já te conto tudo!",
    "🌹 Tô buscando com carinho, tá? Já volto!",
    "😘 Um segundinho, meu bem... preparando com amor!",
  ],
  zoeira: [
    "😎 Calma aí, chefia... tô fuçando nos bastidores!",
    "🕵️‍♂️ Investigando o grupo como um detetive da zoeira...",
    "😂 Peraí que tô puxando os podres do grupo!",
  ],
  neutro: [
    "🔍 Coletando informações, aguarde um instante...",
    "📊 Processando dados do grupo...",
    "⏳ Um momento... já te mostro tudo!",
  ],
};

// 🎲 Escolhe uma frase aleatória
function escolherMensagemEspera(modo) {
  const lista = mensagensEspera[modo] || mensagensEspera.neutro;
  return lista[Math.floor(Math.random() * lista.length)];
}