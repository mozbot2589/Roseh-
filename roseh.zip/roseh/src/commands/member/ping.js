/**
 * Melhorado por: Cyber Rússia 
 * Original por: Frank 
 * Bot: Roseh Bot 🌹
 */

const os = require("os");
const { PREFIX } = require(`${BASE_DIR}/config`);

module.exports = {
  name: "ping",
  description:
    "Verifica se o Roseh Bot está online, mostra o tempo de resposta, uso de sistema e tempo de atividade.",
  commands: ["ping", "pong"],
  usage: `${PREFIX}ping`,
  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({ sendReply, sendReact, startProcess, fullMessage }) => {
    const command = fullMessage.slice(1).toLowerCase();
    const response = command.startsWith("ping") ? "🏓 Pong!" : "🏓 Ping!";

    await sendReact("🌹");

    const ping = Date.now() - startProcess;
    const uptime = formatUptime(process.uptime());

    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsage = ((usedMem / totalMem) * 100).toFixed(2);

    const cpuLoad = os.loadavg()[0].toFixed(2); // Média de 1 minuto
    const platform = os.platform();
    const arch = os.arch();
    const hostname = os.hostname();

    const message = `${response}

🤖 *Roseh Bot está online e radiante!*
📶 *Velocidade de resposta:* \`${ping}ms\`
⏱️ *Tempo de atividade:* \`${uptime}\`
🧠 *Uso de memória:* \`${memUsage}%\`
📦 *Carga da CPU:* \`${cpuLoad}\`
🧭 *Sistema:* \`${platform} ${arch}\`
🏷️ *Host:* \`${hostname}\`

Se precisar de ajuda, digite \`${PREFIX}help\` e Roseh Bot estará ao seu lado com carinho e eficiência! 💖`;

    await sendReply(message);
  },
};

/**
 * Formata o tempo de atividade em horas, minutos e segundos.
 * @param {number} uptime
 * @returns {string}
 */
function formatUptime(uptime) {
  const h = Math.floor(uptime / 3600);
  const m = Math.floor((uptime % 3600) / 60);
  const s = Math.floor(uptime % 60);
  const pad = (num) => String(num).padStart(2, "0");
  return `${pad(h)}h ${pad(m)}m ${pad(s)}s`;
}
