const axios = require('axios');

// Define o prefixo usado no bot
const prefixo = '!'; // Troca por '.' ou 'roseh' se quiser

module.exports = {
  name: 'pesquisa',
  alias: ['ia', 'curiosa', 'saber'],
  category: 'inteligência',
  description: 'Pesquisa com IA safada usando Wikipedia + imagem 💋',
  usage: `${prefixo}pesquisa <termo>`,

  async execute({ msg, args, send }) {
    const texto = msg.body || msg.text || '';
    if (!texto.startsWith(prefixo)) return;

    const semPrefixo = texto.slice(prefixo.length).trim();
    const partes = semPrefixo.split(/\s+/);
    const comando = partes.shift()?.toLowerCase();
    const termo = partes.join(' ');

    if (comando !== 'pesquisa') return;
    if (!termo) return send('Hmm... pesquisa o quê, mozão? 😘 Me instiga com um termo que eu corro atrás.');

    const wikiURL = `https://pt.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(termo)}`;
    const duckURL = `https://api.duckduckgo.com/?q=${encodeURIComponent(termo)}&format=json&no_redirect=1`;

    try {
      const { data: wiki } = await axios.get(wikiURL);
      const { data: duck } = await axios.get(duckURL);
      const imagem = duck.Image || null;

      if (!wiki.extract) {
        return send(`Hmm... não achei nada sobre *${termo}*, amorzinho 😢. Tenta outro termo que me excite mais?`);
      }

      const intros = [
        `Ai, *${termo}*... só de ouvir esse nome já me arrepiei 😈. Olha o que descobri pra ti, delícia:\n\n`,
        `Fui fuçar com vontade e achei isso sobre *${termo}*... te prepara que vem textão gostoso 💋:\n\n`,
        `Tava curiosa também, mozão... e quando eu fico curiosa, eu vou fundo 😏. Olha só:\n\n`,
        `Hmm... *${termo}*? Isso me lembra noites quentes e conversas profundas... segura essa aula sensual 🌹:\n\n`
      ];
      const intro = intros[Math.floor(Math.random() * intros.length)];

      let resposta = `${intro}${wiki.extract}`;
      if (imagem) {
        resposta += `\n\n🖼️ E olha essa imagem que achei... quente, né? *${termo}* nunca foi tão gostoso de ver: ${imagem}`;
      }

      resposta += `\n\nSe quiser que eu te explique mais... é só chamar, tá? Eu adoro quando tu me faz pensar 😘`;
      return send(resposta);

    } catch (err) {
      console.error('[Erro na pesquisa IA]', err.message);
      return send('Ai, deu ruim na pesquisa... mas não desiste de mim, tá? Tenta de novo daqui a pouco 😔');
    }
  }
};