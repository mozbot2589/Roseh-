/**
 * Ritualizado por: Júnio & Roseh Bot 🌹
 * Original por: Mkg
 * Refatorado por: Dev Gui
 */

const { delay } = require("baileys");
const { getRandomNumber } = require(`${BASE_DIR}/utils`);
const { PREFIX, ASSETS_DIR } = require(`${BASE_DIR}/config`);
const { DangerError } = require(`${BASE_DIR}/errors`);
const path = require("node:path");

module.exports = {
  name: "dado",
  description: "Jogue o dado ritualístico da Roseh e invoque seu destino.",
  category: "Jogos",
  commands: ["dado", "dice", "sorte", "ritual"],
  usage: `${PREFIX}dado 4`,
  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({
    args,
    sendWaitReply,
    sendReply,
    sendStickerFromURL,
    sendReact,
    webMessage,
  }) => {
    const number = parseInt(args[0]);
    const pushName = webMessage?.pushName || "Você";

    if (!number || number < 1 || number > 6) {
      throw new DangerError(
        `🎲 *Ritual inválido!*\nEscolha um número entre 1 e 6 para invocar o dado.\nExemplo: ${PREFIX}dado 3`
      );
    }

    await sendWaitReply("🔮 Roseh está rolando o dado...");

    const result = getRandomNumber(1, 6);

    await sendStickerFromURL(
      path.resolve(ASSETS_DIR, "stickers", "dice", `${result}.webp`)
    );

    await delay(2000);

    if (number === result) {
      await sendReact("🏆");
      await sendReply(
        `🎉 *${pushName} invocou com sucesso!*\nVocê escolheu *${number}* e o dado caiu em *${result}*.\n🌟 O destino te abraçou neste ritual. Roseh sorriu.`
      );
    } else {
      await sendReact("🕯️");
      await sendReply(
        `💥 *${pushName} falhou na invocação...*\nVocê escolheu *${number}*, mas o dado caiu em *${result}*.\n😔 O caos venceu. Mas Roseh ainda observa.`
      );
    }
  },
};