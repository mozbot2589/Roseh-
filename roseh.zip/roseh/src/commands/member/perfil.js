const { toUserJidOrLid, isGroup } = require(`${BASE_DIR}/utils`);
const { errorLog } = require(`${BASE_DIR}/utils/logger`);
const { PREFIX, ASSETS_DIR } = require(`${BASE_DIR}/config`);
const { InvalidParameterError } = require(`${BASE_DIR}/errors`);
const { getProfileImageData } = require(`${BASE_DIR}/services/baileys`);

module.exports = {
  name: "perfil",
  description: "Mostra informações de um membro do grupo com estilo moçambicano.",
  commands: ["perfil", "profile"],
  usage: `${PREFIX}perfil ou perfil @usuario`,
  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({
    args,
    socket,
    remoteJid,
    userJid,
    sendErrorReply,
    sendWaitReply,
    sendSuccessReact,
  }) => {
    if (!isGroup(remoteJid)) {
      throw new InvalidParameterError("Este comando só funciona em grupo, chefe!");
    }

    const targetJid = args[0] ? toUserJidOrLid(args[0]) : userJid;

    await sendWaitReply("⏳ Roseh Bot está a puxar ficha do camarada...");

    try {
      let profilePicUrl = `${ASSETS_DIR}/images/default-user.png`;
      let userName = "Camarada Desconhecido";
      let userRole = "Membro";
      let joinedDate = "Não sabemos ainda";

      try {
        const { profileImage } = await getProfileImageData(socket, targetJid);
        if (profileImage) profilePicUrl = profileImage;

        const contactInfo = await socket.onWhatsApp(targetJid);
        userName = contactInfo[0]?.name || userName;
      } catch (error) {
        errorLog(`Erro ao buscar dados do camarada ${targetJid}: ${JSON.stringify(error, null, 2)}`);
      }

      const groupMetadata = await socket.groupMetadata(remoteJid);
      const participant = groupMetadata.participants.find(p => p.id === targetJid);

      if (participant?.admin) userRole = "Chefe do Grupo";
      if (participant?.joinTimestamp) {
        const joinDate = new Date(participant.joinTimestamp * 1000);
        joinedDate = joinDate.toLocaleDateString("pt-BR");
      }

      const random = () => Math.floor(Math.random() * 100);
      const programa = (Math.random() * 5000 + 1000).toFixed(2);
      const gado = random() + 7;
      const passiva = random() + 5;
      const beleza = random() + 1;

      const mensagem = `
🌍 *Ficha do camarada @${targetJid.split("@")[0]}*

👤 *Nome:* ${userName}
🎖️ *Cargo:* ${userRole}
📆 *Entrou no grupo:* ${joinedDate}
📍 *Província:* Maputo (Roseh adivinhou 😄)

💸 *Preço do show:* R$ ${programa} — esse camarada não sai barato, hein!
🐮 *Nível de gado:* ${gado}% — maningue gado, já tá a pagar xima com sentimento!
🎱 *Modo passivo:* ${passiva}% — esse aqui só recebe carinho, tipo sofá de sala!
✨ *Nível de beleza:* ${beleza}% — bué de bonito, parece que foi feito em Maputo Shopping!

Com respeito e alegria,  
*Roseh Bot 🌹* — sempre firme, sempre presente! 🇲🇿`;

      await sendSuccessReact();

      await socket.sendMessage(remoteJid, {
        image: { url: profilePicUrl },
        caption: mensagem,
        mentions: [targetJid],
      });
    } catch (error) {
      console.error(error);
      sendErrorReply("Eish... deu erro ao puxar a ficha. Roseh tá a tentar de novo.");
    }
  },
};