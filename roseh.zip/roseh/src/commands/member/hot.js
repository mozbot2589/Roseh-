/**
 * author Dev Gui
 */
const { PREFIX, BOT_NAME } = require(`${BASE_DIR}/config`);
const packageInfo = require(`${BASE_DIR}/../package.json`);
const { getDateInfo } = require(`${BASE_DIR}/utils/date`);
const { getRandomItem } = require(`${BASE_DIR}/utils/random`);
const { delay } = require(`${BASE_DIR}/utils/time`);

module.exports = {
  name: "menuhot",
  description: "Menu provocante e teatral da Roseh Bot",
  commands: ["menuhot", "rosehhot"],
  usage: `${PREFIX}menuhot`,
  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({ sendMessage }) => {
    const { hora, dia, saudacao, statusEmocional } = getDateInfo();

    const reacoes = [
      "Roseh tá sentindo o calor do grupo…",
      "Hmm… esse comando me deixou arrepiada.",
      "Segura que vem delírio.",
      "Modo provocante ativado… preparando conteúdo.",
    ];

    const espera = [
      "Carregando com tesão digital…",
      "Roseh tá buscando algo quente pra ti.",
      "Processando desejos ocultos do grupo…",
    ];

    const finais = [
      "Pronto. Agora respira fundo e finge que não sentiu nada.",
      "Missão provocante concluída. Até o próximo surto.",
      "Se essa resposta te deixou quente, imagina o próximo comando.",
    ];

    const menu = `
╭━━━ 💋 *Menu Roseh Safadona* 💋 ━━━╮

${saudacao}  
📅 *Hoje é ${dia}, são ${hora}.*  
💓 *Status emocional:* ${statusEmocional}  
🎙️ *Presença digital:* ${BOT_NAME} v${packageInfo.version}

🎧 *1.* \`${PREFIX}gemido\` – Sons e frases que fazem tremer  
💌 *2.* \`${PREFIX}confissão\` – Desejos secretos revelados  
🕵🏽‍♀️ *3.* \`${PREFIX}segredo\` – Revelações do grupo (com drama)  
🤯 *4.* \`${PREFIX}punheta\` – Tesão insano e exagerado  
😵 *5.* \`${PREFIX}surto\` – Modo surtada ativado  
🎭 *6.* \`${PREFIX}intuição\` – Pressentimento sobre alguém  
📜 *7.* \`${PREFIX}relatorio\` – Análise emocional do grupo  
🧬 *8.* \`${PREFIX}genegrupo\` – DNA simbólico do grupo  
🗣️ *9.* \`${PREFIX}psicogrupo\` – Diagnóstico coletivo teatral  
🎥 *10.* \`${PREFIX}video18\` – Clipe provocante sobre o grupo  
📸 *11.* \`${PREFIX}foto18\` – Imagem simbólica com tensão

╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
*Roseh não é só bot… é calor digital.* 😈
`;

    await sendMessage(getRandomItem(reacoes));
    await delay(1000);
    await sendMessage(getRandomItem(espera));
    await delay(1500);
    await sendMessage(menu);
    await sendMessage(getRandomItem(finais));
  },
};