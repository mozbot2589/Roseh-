/**
 * @author Dev Júnio & Roseh Bot 🌺
 * @description Responde ao menu do comando rosehvagasmz com o link e frase provocante,
 * e reage com emoji diferente pra cada fonte.
 */

const { PREFIX } = require(`${BASE_DIR}/config`);

module.exports = {
  name: "rosehvagasmzresponde",
  description: "Responde ao menu de fontes de emprego com reação",
  commands: ["rosehvagasmzresponde"],
  usage: `${PREFIX}rosehvagasmzresponde [1|2|3]`,

  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({ args, sendText, react }) => {
    const escolha = args[0];
    const respostas = {
      "1": {
        texto: "📢 *Sovagas tá fervendo hoje!*\n🔗 https://sovagas.co.mz",
        emoji: "📢",
      },
      "2": {
        texto: "💼 *MMO Emprego tá cheio de trampo bom!*\n🔗 https://emprego.mmo.co.mz",
        emoji: "💼",
      },
      "3": {
        texto: "📝 *Emprego.co.mz tem vaga até pra quem sabe provocar com emoji!*\n🔗 https://www.emprego.co.mz",
        emoji: "📝",
      },
    };

    const resposta = respostas[escolha];
    if (!resposta) {
      await react("❌");
      await sendText("😕 Escolha inválida. Tenta com 1, 2 ou 3.");
      return;
    }

    await react(resposta.emoji);
    await sendText(resposta.texto);
  },
};