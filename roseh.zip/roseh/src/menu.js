const { BOT_NAME } = require("./config");
const packageInfo = require("../package.json");
const { readMore } = require("./utils");
const { getPrefix } = require("./utils/database");

exports.menuMessage = (groupJid) => {
  const date = new Date();
  const prefix = getPrefix(groupJid);

  return `╭━━❰ 🌺 BEM-VINDO À ZONA DA ROSEH ❱━━${readMore()}
┃
┃ 🪐 *Bot:* ${BOT_NAME}
┃ 📅 *Data:* ${date.toLocaleDateString("pt-mz")}
┃ ⏰ *Hora:* ${date.toLocaleTimeString("pt-mz")}
┃ 🔣 *Prefixo:* ${prefix}
┃ 🧬 *Versão:* ${packageInfo.version}
┃
┣━━❰ 🎭 COMANDOS TEATRAIS ❱━━
┃ • ${prefix}evangelho — capítulos da criação
┃ • ${prefix}culto — mantras do caos
┃ • ${prefix}milagre — testemunhos de grupos
┃ • ${prefix}dono — revela o invocador supremo
┃ • ${prefix}deus — invoca a divindade original
┃
┣━━❰ 🛡️ COMANDOS DE ZONA ❱━━
┃ • ${prefix}entrada — ritual de chegada
┃ • ${prefix}saida — ritual de despedida
┃ • ${prefix}status-zona — estado espiritual do grupo
┃
┣━━❰ 🧪 COMANDOS TÉCNICOS ❱━━
┃ • ${prefix}ping — desempenho da Roseh
┃ • ${prefix}ajuda — instruções e suporte
┃
┣━━❰ 👤 PERFIL DO CAMARADA ❱━━
┃ • ${prefix}perfil — ficha provocante do membro
┃
╰━━━⌬ *Roseh Bot 🌹 — feita pra provocar, proteger e performar com alma moçambicana.* ⌬`;
};