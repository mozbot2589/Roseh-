/**
 * Mensagens de boas-vindas e despedidas com personalidade Mozambicana 🌍
 * Use "@member" para mencionar quem entrou ou saiu.
 * Sinta-se livre para adaptar conforme o clima do grupo (zoeira, romântico, madrugada…)
 *
 * @autor Dev Gui + Roseh Bot 🌹 vibes
 */
module.exports = {
  welcomeMessage: [
    "🎉 Chegou quem faltava! @member, entra com pé direito e coração aberto!",
    "🌺 Bem-vindo(a), @member! Aqui é tipo quintal de casa: risada, afeto e boa conversa!",
    "🫶 @member entrou no grupo! Já pode pedir música e contar fofoca 😄",
    "💃🏾 Olha o(a) danado(a) chegando! @member, senta aí que o grupo ficou mais bonito!",
    "✨ @member, seja muito bem-vindo(a)! Aqui a vibe é boa, o papo é quente e o carinho é garantido!",
  ],

  exitMessage: [
    "😢 @member saiu do grupo… Vai com Deus e com os dados móveis!",
    "💔 Partiu sem deixar selfie… @member, o grupo já tá com saudades!",
    "🕊️ Adeus, @member… Que os grupos por aí te recebam com o mesmo carinho!",
    "👣 @member deixou o grupo… Mas deixou também boas lembranças!",
    "📴 @member desconectou… Mas a conexão com a gente continua no coração!",
  ],
};