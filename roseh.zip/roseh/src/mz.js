/**
 * @author Dev Júnio & Roseh Bot 🌺
 * @description Compartilha vagas reais de Moçambique com frases provocantes,
 * usando menu por texto e reação emoji.
 */

const { PREFIX } = require(`${BASE_DIR}/config`);

module.exports = {
  name: "rosehvagasmz",
  description: "Vagas reais e quentes só pra Moçambique (com reação emoji)",
  commands: ["rosehvagasmz", "vagasmoz", "empregomz", "trampomz"],
  usage: `${PREFIX}rosehvagasmz`,

  /**
   * @param {CommandHandleProps} props
   * @returns {Promise<void>}
   */
  handle: async ({ sendText, react }) => {
    // Reage à mensagem do usuário com emoji quente
    await react("🔥");

    // Envia menu por texto
    const menu = `
🌺 *Vagas reais só pra Moçambique:*

Roseh separou umas fontes quentes pra ti... escolhe uma e responde com o número 😏

1️⃣ Sovagas  
2️⃣ MMO Emprego  
3️⃣ Emprego.co.mz

*Responde com o número da fonte que tu quer ver.*
    `;
    await sendText(menu);
  },
};